if (!(Invoke-Sqlcmd -Query {select�*�from�sys.server_principals�where�name�=�'${SQLLoginName}'})) 
{Write-Host "User : ${SQLLoginName} not in Server role";Invoke-Sqlcmd -Query { create login ${SQLLoginName} with password = 'Welcome@123'};
Write-Host "User : ${SQLLoginName} server role created";if((Invoke-Sqlcmd -Query {USE ${DBName}; select name from sys.database_principals�where�type_desc�=�'SQL_USER' and name = '${SQLLoginName}'}))
{Write-Host "User: ${SQLLoginName} Already exists in the DB ${DBName}"; $a = (Invoke-Sqlcmd -Query {USE ${DBName};select b.name as group1, c.name as member from sys.database_role_members as a join sys.database_principals as b on a.role_principal_id = b.principal_id join sys.database_principals as c on a.member_principal_id = c.principal_id})
$b = $a | where {$_.member -eq "${SQLLoginName}"} | where {$_.group1 -eq "${DBRoleName}"};if ($b){
Write-Host "User already have access to db_read";}else{Invoke-Sqlcmd -Query {USE ${DBName}; ALTER ROLE ${DBRoleName} ADD MEMBER ${SQLLoginName}}
Write-Host "User : ${SQLLoginName} added to the databaserole  ${DBRoleName}";}}else{Invoke-Sqlcmd -Query {USE ${DBName}; CREATE�USER�${SQLLoginName}�FOR�LOGIN�${SQLLoginName}; ALTER ROLE ${DBRoleName} ADD MEMBER ${SQLLoginName}}
Write-Host "DB role created for the user ${SQLLoginName} and added to databaserole ${DBRoleName}"}}else{Write-Host "User: ${SQLLoginname} already exists in the Server role" 
Invoke-Sqlcmd -Query {USE ${DBName};CREATE�USER�${SQLLoginName}�FOR�LOGIN�${SQLLoginName}; ALTER ROLE ${DBRoleName} ADD MEMBER ${SQLLoginName}}
Write-Host "DB role created for the user ${SQLLoginName} and added to databaserole ${DBRoleName}"}

invoke-command -computername cch1imstest1.pwtest1.com -scriptblock {if ((Invoke-Sqlcmd -Query {SELECT name FROM sys.server_principals WHERE name = '${SQLLoginName}'}).name -ne '${SQLLoginName}')
{
Invoke-Sqlcmd -Query {create login ${SQLLoginName} with password = 'Welcome@123';}
} 
else
{ 
'Account already exists'
} }


invoke-command -computername cch1imstest1.pwtest1.com -scriptblock {if ((Invoke-Sqlcmd -Query {SELECT name FROM sys.server_principals WHERE name = '${SQLLoginName}'}).name -ne '${SQLLoginName}')
{
Invoke-Sqlcmd -Query {CREATE LOGIN [CCH1IMSTEST1\${SQLLoginName}] FROM WINDOWS;}
Write-Host "Windows Account CCH1IMSTTEST1\${SQLLoginName} is added to SQL Server Role"
} 
else
{ 
Write-Host "Windows Account CCH1IMSTTEST1\${SQLLoginName} is already in SQL Server Role
} 
}
CREATE LOGIN [CCH1IMSTEST1\sqltest1] FROM WINDOWS
CREATE LOGIN [CCH1IMSTEST1\sqltest] FROM WINDOWS WITH DEFAULT_DATABASE=[master]


$u="pwtest1\arago"
$p="arago" | ConvertTo-SecureString -AsPlainText -Force
$credential = New-Object System.Management.Automation.PSCredential($u,$p);
invoke-command -computername cch1imstest1.pwtest.com -scriptblock {hostname}  -credential $credential

