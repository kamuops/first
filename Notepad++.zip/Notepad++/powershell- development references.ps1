SCCM find hostname

Invoke-Command -ComputerName cch1wtsccmsn.pwtest1.com -Scriptblock {Import-module "E:\Program Files\Microsoft Configuration Manager\AdminConsole\bin\ConfigurationManager.psd1"; cd A01:;$("${HostName}").split(",") | %{(Get-CMDevice -Name "$_" | Select -ExpandProperty Name)}};
---------------------------

Add hostname to the collection

Import-module "${SCCMInstallationDir}"
cd ${HexSitePath}
Add-CMDeviceCollectionDirectMembershipRule -CollectionId "${CollectionID}" -ResourceID $(get-cmdevice -name "${HostName}").ResourceID
--------------------------------------------

Check target machine is in lan

if (!(test-Connection -Cn ${HostName} -quiet)) { Write-Host offline} else { Write-Host online }

---------------------------------------------------------------------------------
check software isntallation status 
$query = sqlcmd -S ${SCCMDBServer#${Location}} -d ${DatabaseName} -Q "
select  distinct 
case when fn.appstate='1000' then 'Success'
when fn.appstate='1001' then 'Already Compliant'
when fn.appstate='1002' then 'Simulate Success'
when fn.appstate='2000' then 'In progress'
when fn.appstate='5010' then 'Failed to updating App-V Virtual Environment'
end as 'Laststatusmessage'
from fn_AppDTClientSummarizedState('') fn join v_r_system vrs on vrs.name0=fn.machinename
where MachineName in ('${HostName}') and applicationname like ('%${SoftwareQueryString#${SoftwareName}}%')
 "
$query

---------------------------------------------------------------
create a entry in sccm directory

echo "${HostName}" > "${TriggerDirectory}\To Process\${SitePath#${Location}}\${HostName}.txt"

---------------------------------------------------------
Check task sequence status

$url = "${StatusUpdateAPIURL}SR${incident_id}/Checkstatus"
$headers = New-Object "System.Collections.Generic.Dictionary[[String],[String]]"
$headers.Add("AuthenticationToken", "EULAIDtultCl")
$res = Invoke-RestMethod -Uri $url -Headers $headers -Method Post -ContentType "application/json"
($res | ConvertFrom-Json).SCCMStatus

-------------------------------------------------------------------------------------------------------------------------
It will trigger SQL Store Procedure For Genie Access Removal Output

sqlcmd -S "${GenieDBServer}" -d "${GenieDatabaseName}" -Q "EXEC Hex_USP_Revoke_Genieplus_Access '${EmployeeID}'"

sqlcmd -S "cch1wpgeniedb1" -d "CCH1WPSUDB1_Prod" -Q "EXEC Hex_USP_Revoke_Genieplus_Access '41013'"

----------------------------------------------------------------------------------------------------------------
Removal of ART employee login

$url = "http://172.25.121.132:8088/DisEnrollArtUser";
$headers = @{"authenticationToken" = "EULAIDtultCl"};
$body = '{ "userId": "36816","reason": "Employee resigned from the organization","tracerefId":"117702"}';
$result = Invoke-WebRequest -Uri $url -Headers $headers -TimeoutSec 1800 -ErrorAction:Stop -UseBasicParsing -Body $body -Method POST -ContentType "application/json";echo $result.Content


$url = "${ARTRestAPIURL}";
$headers = @{"authenticationToken" = "EULAIDtultCl"};
$body = '{ "userId": "${EmployeeID}","reason": "Employee resigned from the organization","tracerefId":"${incident_id}"}';
$result = Invoke-WebRequest -Uri $url -Headers $headers -TimeoutSec 1800 -ErrorAction:Stop -UseBasicParsing -Body $body -Method POST -ContentType "application/json";echo $result.Content
--------------------------------------------------------------------------------------------


trigger script for SCCM

function sccm
{
Try {
$computer = $args[0]
$SCCMClient = [wmiclass] "\\$computer\root\ccm:SMS_client"
$SCCMClient
$SCCMClient.TriggerSchedule("{00000000-0000-0000-0000-000000000121}")
$SCCMClient.TriggerSchedule("{00000000-0000-0000-0000-000000000003}")
$SCCMClient.TriggerSchedule("{00000000-0000-0000-0000-000000000010}")
$SCCMClient.TriggerSchedule("{00000000-0000-0000-0000-000000000001}")
$SCCMClient.TriggerSchedule("{00000000-0000-0000-0000-000000000021}")
$SCCMClient.TriggerSchedule("{00000000-0000-0000-0000-000000000022}")
$SCCMClient.TriggerSchedule("{00000000-0000-0000-0000-000000000002}")
$SCCMClient.TriggerSchedule("{00000000-0000-0000-0000-000000000031}")
$SCCMClient.TriggerSchedule("{00000000-0000-0000-0000-000000000114}")
$SCCMClient.TriggerSchedule("{00000000-0000-0000-0000-000000000113}")
$SCCMClient.TriggerSchedule("{00000000-0000-0000-0000-000000000111}")
Move-Item -Path "${ToProcess}\${Machine}.txt" -Destination "${Processed}" -Force
echo "${TIME} :- Scheduled Software Installation on ${Machine}" >> $Log
}
catch [System.Management.Automation.PSInvalidCastException] {
    echo "'$Machine' is dead" >> $Log
}

}

#Main Program Starts Here

#$ToProcess="\\172.25.164.46\Software_Automation\To Process"
#$Processed="\\172.25.164.46\Software_Automation\Processed"

$Time = Get-Date -Format "HH:mm:ss"
$hostname=hostname
$LogfileName=get-date -format "dd-MM-yyyy"
$Log="\\172.25.164.46\Software_Automation\Exec Log\${hostname}-${LogfileName}.txt"


switch -wildcard ($hostname) 
    { 
        "*cch1wpsccm*"	{
			$script:ToProcess="\\172.25.164.141\Software_Automation\To Process\CHN"
			$script:Processed="\\172.25.164.141\Software_Automation\Processed\CHN"
			#Remove-Item -Force -Recurse "\\172.25.164.46\Software_Automation\To Process"
			} 
        "*mhp1wpsccm*"	{
			$script:ToProcess="\\172.25.164.141\Software_Automation\To Process\MUM"
			$script:Processed="\\172.25.164.141\Software_Automation\Processed\MUM"
			}
		"*usa1wpsccm*"	{
			$script:ToProcess="\\172.25.164.141\Software_Automation\To Process\USA"
			$script:Processed="\\172.25.164.141\Software_Automation\Processed\USA"
			} 
        "*pun1wpsccm*" {
			$script:ToProcess="\\172.25.164.141\Software_Automation\T`o Process\PUN"
			$script:Processed="\\172.25.164.141\Software_Automation\Processed\PUN"
		} 
        
    }


#New-Item "${ToProcess}" -type directory -Force
#New-Item -ItemType Directory -Force -Path ${Processed}
#New-Item "${Processed}" -type directory -Force
#Remove-Item -Force -Recurse "\\172.25.164.46\Software_Automation\MHP"

#echo "${TIME} :- ${ToProcess}" >> $Log
#echo "${TIME} :- ${Processed}" >> $Log

if (( Get-ChildItem "${ToProcess}" -Filter *.txt | Measure-Object ).Count -ne 0 )
{
    Get-ChildItem "${ToProcess}" -Filter *.txt |
    Foreach-Object {
        $Machine = Get-Content $_.FullName
		sccm "$Machine"     #Calling SCCM Function with the given hostname as Args
    }
}
else {
    echo "${TIME} :- Result : No File to process" >> $Log
}
-------------------------------------------------------------------------------------
if( Get-WmiObject Win32_UserAccount -filter "LocalAccount=True" | where {$_.Name -eq "${SQLLoginName}"} |Select-Object Name)
{
Write-Host "user ${SQLLoginName}" already exists in the server
}
else
{
NET USER ${SQLLoginName} "Welcome@123" /ADD;
NET LOCALGROUP "Administrators" "${SQLLoginName}" /add
Write-Host " user ${SQLLoginName} added Successfully as Local Account"
}
--------------------------------------------------------------------------------------------

$UserName = "raiseitfsadmin@hexawareonline.onmicrosoft.com";
$Password =ConvertTo-SecureString -String "Welcome@123" -AsPlainText -Force;
$Credential = New-Object -TypeName System.Management.Automation.PSCredential -ArgumentList 
$UserName,$Password;
Import-Module AzureRM;
Login-AzureRmAccount -Credential $Credential;
$UserName = "HexawareAdmin";
$Password =ConvertTo-SecureString -String "Pass@1234" -AsPlainText -Force;
$cred = New-Object -TypeName System.Management.Automation.PSCredential -ArgumentList 
$UserName,$Password;
New-AzureRmVm -ResourceGroupName 'RaiseIT_Automation_RG' -Name 'CCHWINWEB01' -Location 'SouthIndia' -VirtualNetworkName 'RaiseIT_Automation_VN' -SubnetName 'RaiseIT_Automation_SN' -Size 'Standard_B1ms' -SecurityGroupName 'CCHWINWEB01' -PublicIpAddressName 'CCHWINWEB01' -ImageName 'MicrosoftWindowsServer:WindowsServer:2016-Datacenter:latest' -Credential $cred | out-null;Get-AzureRMVM -Name 'CCHWINWEB01' -ResourceGroupName 'RaiseIT_Automation_RG' | Get-AzureRmPublicIpAddress | select -ExpandProperty IpAddress
9487037200
--------------------------------------------------------------------

New Azure VM CCHWINWEB01 has been successfully created. Machine can be accessed using the IP - Account SubscriptionName TenantId Environment------- ---------------- -------- -----------RaiseitFSadmin@hexawareonline.onmicrosoft.com Free Trial 7c0c36f5-af83-4c24-8844-9962e0163719 AzureCloud104.211.203.198

$listName = "${SharePointList}" ;
$xmlDoc = new-object System.Xml.XmlDocument;
$query = $xmlDoc.CreateElement("Query");
$viewFields = $xmlDoc.CreateElement("ViewFields");
$queryOptions = $xmlDoc.CreateElement("QueryOptions");
$query.set_InnerXml("FieldRef Name='Full Name'");
$rowLimit = "1000";
$list = $null;
$service = $null;
//// $pwd = Convertto-SecureString "raju$123" -asplaintext -force
////PS C:\Users\30677> $StandardString = ConvertFrom-SecureString $pwd
[byte[]]$key = ${AragoKerberosAccountKey}; /// $key = New-object Byte[] 16 [Security.Cryptography.RNGCryptoServiceProvider]::Create().GetBytes($Key)
$password = $("${AragoKerberosAccountPwd}".TrimEnd()) | ConvertTo-SecureString -key $key;
$username = "${AragoKerberosAccountUname}" ;
$credential = New-Object System.Management.Automation.PSCredential($username,$password);
$service = New-WebServiceProxy -Uri $uri  -Namespace SpWs  -Credential $credential;
$list = $service.GetListItems($listName, "", $query, $viewFields, $rowLimit, $queryOptions, "");
$ndlistview = $service.getlistandview($listname, "");
$strlistid = $ndlistview.childnodes.item(0).name;
$strviewid = $ndlistview.childnodes.item(1).name;
$xmldoc = new-object system.xml.xmldocument;
$batchelement = $xmldoc.createelement("Batch");
$batchelement.setattribute("onerror", "continue");
$batchelement.setattribute("listversion", "1");
$batchelement.setattribute("viewname", $strviewid);
$xml = "";
$xml += "<Method ID='1' Cmd='New'>" + "<Field Name='Title'>${ServerName}</Field>" +  "<Field Name='Region'>${SPUpdateOutput}></Field>" + "</Method>";
$batchelement.innerxml = $xml;
$ndreturn = $null;
$ndreturn = $service.updatelistitems($listName, $batchelement);]]></Parameter>