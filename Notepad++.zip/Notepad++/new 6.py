from flask import Flask, request
from flask_restful import Resource, Api
from flask_httpauth import HTTPBasicAuth
from json import dumps
import os
import json, yaml
from subprocess import Popen,PIPE
import sys,re
from logger import *

app = Flask(__name__)
api = Api(app)
auth = HTTPBasicAuth()

filePath='/root/Priya/fileTransfer/filestore/'

initialize_logger()
USER_DATA = {
    "admin": "SuperSecretPwd"
}
@auth.verify_password
def verify(username, password):
    if not (username and password):
        return False
    return USER_DATA.get(username) == password

class getfile(Resource):
        """ get Filename and return file content for the given Filename """
        @auth.login_required
        def get(self):
                filename = request.args.get('fileName')
                logging.info(filename)
                fullPath=filePath+filename
                logging.info(fullPath)
                try:
                        with open(fullPath) as f:
                                content = f.readlines()
                                return(content)
                except Exception as e:
                        message={"status":"file cannot be read","error":str(e)}
                        return(message)

class deletefile(Resource):
        """ get Filename and delete file """
        @auth.login_required
        def get(self):
                filename = request.args.get('fileName')
                logging.info(filename)
                fullPath=filePath+filename
                try:
                        os.remove(fullPath)
                        message={"status":"successfully deleted","error":"null"}
                except Exception as e:
                        message={"status":"file cannot be deleted","error":str(e                                                                                        )}
                return(message)

class putfile(Resource):
        """ get json and store in the specified path"""
        @auth.login_required
        def post(self):
                json_data = request.get_json(force=True)
                filecontent = json_data["Issuecontent"]
                filename = json_data["Issueid"]
                fullPath=filePath+filename
                try:
                        with open(fullPath,'w') as f:
                                f.write(filecontent)
                        return { "status":"File stored in the specified path","F                                                                                        ilePath":fullPath}
                except Exception as e:
                        return { "status":"File not stored in the specified path                                                                                        ","FilePath":fullPath}


api.add_resource(putfile, '/putfile')
api.add_resource(getfile, '/getfile')
api.add_resource(deletefile, '/deletefile')

if __name__ == '__main__':
     app.run(host = '172.25.145.225',port=4444)
