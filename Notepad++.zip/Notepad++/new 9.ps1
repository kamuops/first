clear
Get-Process excel | Stop-Process -Force
$FilePath = "D:\adgrp.xlsx"
$SheetName = "Sheet1"
$objExcel = New-Object -ComObject Excel.Application 
$objExcel.Visible = $true
$objExcel.DisplayAlerts = $true
$WorkBook = $objExcel.Workbooks.Open($FilePath)
$WorkSheet = $WorkBook.sheets.item($SheetName)
$WorksheetRange = $workSheet.UsedRange
$R = $WorksheetRange.Rows.Count
$C = $WorksheetRange.Columns.Count
$WorkSheet.Cells.Item(1,$c+1) = "Status"
$F1 = $WorkSheet.Cells.Find('WO NO').column
$F2 = $WorkSheet.Cells.Find('EMPID').column
#$F3 = $WorkSheet.Cells.Find('HOSTNAME').column
$F4 = $WorkSheet.Cells.Find('AD GROUP').column
$F5 = $WorkSheet.Cells.Find('DESCRIPTION').column
for ($i=2;$i-lt$R+1;$i++)
{
$EmployeeID = $WorkSheet.Cells.Item($i,$F2).value2
$GroupName =  $WorkSheet.Cells.Item($i,$F4).value2
#$computer = $WorkSheet.Cells.Item($i,$F3).value2
$sw = $WorkSheet.Cells.Item($i,$F5).value2
switch($sw)
{
'Add Employee to AD Project Group' 
{
$Error.Clear()
Get-ADUser -Identity $EmployeeID
if($Error)
{
$WorkSheet.Cells.Item($i,$c+1)= "User not available in AD"
}
else
{
$a=(Get-ADGroupMember -Identity "$GroupName").SamAccountName -contains "$EmployeeID"
if($a)
{
$WorkSheet.Cells.Item($i,$c+1)= "User already available in $GroupName"
}
else
{ 
#Add-adgroupmember -Identity "$GroupName" -members "$EmployeeID"
$WorkSheet.Cells.Item($i,$c+1)="Add Employee to AD Project Group"
}}}
}

'New AD Group Creation' 
{
$WorkSheet.Cells.Item($i,$c+1)="New AD Group Creation"
#$ADGroup = "cch1wpdc03.corp.hexaware.com";Invoke-command -computername $ADGroup -Authentication Kerberos -scriptblock {New-ADGroup -Name "$GroupName" -SamAccountName "PRJ-7116" -GroupCategory Security -GroupScope Universal -DisplayName "$GroupName" -Path "OU=Groups & Contacts,OU=Campus,DC=corp,DC=hexaware,DC=com" -Description "Created for Project $GroupName"

}
'Remove Employee from AD Project Group' 
{
#remove-adgroupmember -Identity $GroupName -members $EmployeeID -Confirm:$false
$WorkSheet.Cells.Item($i,$c+1)="Remove Employee from AD Project Group"}
}
#$WorkBook.save()
#$objExcel.quit() 


________________________________________

Please do not print this email unless it is absolutely necessary.
