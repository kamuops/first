----------------------Add Windows User to SQL Server Role----------------------------------

cjw8upfaa6at44b33pbqctra7 - SQL : Initiate Creating Windows user and adding user to SQL Server Role
cjw8v3nv76ay94b3328p8qzaq  - SQL: Decision After Initiate creating windows user and adding user to sql server role
cjw8vf3g06b3x4b33ssvl06pr - SQL: Create Windows Local Account
cjw8w32j06bah4b33t9zegrfc - SQL: Decision after creating Windows Local Account
cjw9d9ouy752d4b33w9mc1260 - SQL: Adding Windows User Account to SQL Role
cjw9dok6875f54b338rxtkle8 - SQL: Decision After Adding Windows User to SQL Server
cjvrpqt3p0jko4b336eeg79e8 - SQL : Add user to Server Role on MSSQL Database
cjjkidzh00vqq4b33tv89p5yp - SQL : Decision After adding user to SQL role

----------------------Create SQL user and add to server role----------------------------------
cjvromzwf0us24b33pvko2rvv - SQL : Initiate Creating SQL User and adding user to Server Role
cjvrpgv220vfa4b33kr23ail8 - SQL: Decision After Initiate Creating SQL User and adding user to Server Role
cjvrpqt3p0vio4b336eeg79e8 - SQL: Create SQL user on MSSQL Database
cjvrqdzh00vqq4b33tv89p5yp - SQL : Decision After Creating SQL user
cjvrpqt3p0jko4b336eeg79e8 - SQL : Add user to Server Role on MSSQL Database
cjjkidzh00vqq4b33tv89p5yp - SQL : Decision After adding user to SQL role

----------------------- ADD User to DB Role -----------------------------------------------------

cjvrdbzwf0us24b33pvko2rvv - SQL : Initiate Add User to database Role
cjvrdbv220vfa4b33kr23ail8 - SQL: Decision After Initiate adding User to DB Role
cjvrdbt3p0vio4b996eeg79e8 - SQL: Check Existense of User on SQL Server Login
cjdecdzh00vqq4b33db89p5yp - SQL : Decision After Checking user Existence on SQL Server
cjvrdbt3p0vio4b336eeg79e8 - SQL: Add user to DB Role
cjdbqdzh00vqq4b33db89p5yp - SQL : Decision After Adding user to DB Role

---------------------------Kill DB Blocking session --------------------
cjw8upfjk6at44b33pbqctra7 - SQL : Initiate killing the blocking session on DB Instance
cjw8v3nv76ay94b3328p8decq - SQL: Decision After Initiate killing the blocking session on MSSQL DB
cjw8vf3g06b3x4b33idenl06pr - SQL: Identify DB Blocking Session
cjw8w32j06bah4b33t9zegide - SQL: Decision after Identify DB Blocking Session
cjw9d9blo752d4b33w9mc1260 - SQL: Kill Blocking session on MSSQL DB
cjblodec00vqq4b33tv89p5yp - SQL : Decision after Kill Blocking session on MSSQL DB


