import yaml
import yamlordereddictloader
 
with open("Email.yaml", "r") as f:
	yaml_data = yaml.load(f.read())
	print(yaml_data)
	print(type(yaml_data))
	for value in yaml_data['EmailDetails']:
        EmailId=value['command']
      
       


	
	