r'''
import json
x = '{"name":"Kamu" , "Age": 25}'
y = json.loads(x)
print(y["name"])

#=========================================
import sys
print("Number of Arguments:",len(sys.argv))
print("Argument list", str(sys.argv))
print(sys.argv[0])

#=================================
import configparser
class AttrDict(dict):
    def __init__(self, *args, **kwargs):
        super(AttrDict, self).__init__(*args, **kwargs)
        self.__dict__ = self

config = configparser.ConfigParser(dict_type=AttrDict)
config.read(r"C:\Users\30677\Desktop\Auto Deployer\EmailConfig.ini")

print(config._sections.EmailDetails.)


#===============================================


import re
with open('mylog.log','r') as log:
	for line in log:
		if re.match("2012/09/30-00:00:1[0-3]", line):
			print line
##############======================================
'''

a = input("enter the value:")
b = input("Enter the Value:")
mystring = "entered value is {},{}"
print(mystring.format(a,b))

=============================================================

import os

directory = '/home/coffee/Documents'

os.system("find " + directory + " -mtime +60 -print")
os.system("find " + directory + " -mtime +60 -delete")

==================================================
find /path/to/files/ -type f -name '*.jpg' -mtime +30 -exec rm {} \;
